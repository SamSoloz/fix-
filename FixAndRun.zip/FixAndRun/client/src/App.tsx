import { Canvas } from "@react-three/fiber";
import { Suspense, useState } from "react";
import { OrbitControls } from "@react-three/drei";
import "@fontsource/inter";
import BridgeModel from "./components/BridgeModel";
import ViewControls from "./components/ViewControls";
import MaterialProperties from "./components/MaterialProperties";
import ComponentTree from "./components/ComponentTree";
import DimensionAnnotation from "./components/DimensionAnnotation";

export type ViewMode = 'perspective' | 'plan' | 'front' | 'side';

function App() {
  const [viewMode, setViewMode] = useState<ViewMode>('perspective');
  const [selectedComponent, setSelectedComponent] = useState<string | null>(null);
  const [showDimensions, setShowDimensions] = useState(true);
  const [showMaterials, setShowMaterials] = useState(true);

  const getCameraPosition = (mode: ViewMode): [number, number, number] => {
    switch (mode) {
      case 'plan':
        return [0, 30, 0];
      case 'front':
        return [0, 5, 25];
      case 'side':
        return [25, 5, 0];
      default:
        return [20, 15, 20];
    }
  };

  return (
    <div style={{ width: '100vw', height: '100vh', position: 'relative', background: '#f0f0f0' }}>
      {/* Top Controls Panel */}
      <div className="absolute top-4 left-4 right-4 z-10 flex gap-4">
        <ViewControls 
          viewMode={viewMode} 
          onViewModeChange={setViewMode}
          showDimensions={showDimensions}
          onToggleDimensions={() => setShowDimensions(!showDimensions)}
          showMaterials={showMaterials}
          onToggleMaterials={() => setShowMaterials(!showMaterials)}
        />
      </div>

      {/* Left Side Panel - Component Tree */}
      <div className="absolute left-4 top-20 z-10">
        <ComponentTree
          selectedComponent={selectedComponent}
          onSelectComponent={setSelectedComponent}
        />
      </div>

      {/* Right Side Panel - Material Properties */}
      {showMaterials && (
        <div className="absolute right-4 top-20 z-10">
          <MaterialProperties />
        </div>
      )}

      {/* 3D Canvas */}
      <Canvas
        camera={{
          position: getCameraPosition(viewMode),
          fov: 45,
          near: 0.1,
          far: 1000
        }}
        gl={{
          antialias: true,
          powerPreference: "high-performance"
        }}
      >
        {/* Background */}
        <color attach="background" args={["#e8f4fd"]} />

        {/* Lighting */}
        <ambientLight intensity={0.4} />
        <directionalLight
          position={[10, 10, 5]}
          intensity={1}
          castShadow
          shadow-mapSize-width={2048}
          shadow-mapSize-height={2048}
          shadow-camera-far={50}
          shadow-camera-left={-20}
          shadow-camera-right={20}
          shadow-camera-top={20}
          shadow-camera-bottom={-20}
        />
        <directionalLight
          position={[-10, 5, -5]}
          intensity={0.3}
        />

        {/* Camera Controls */}
        <OrbitControls
          enablePan={true}
          enableZoom={true}
          enableRotate={viewMode === 'perspective'}
          target={[0, 0, 0]}
        />

        {/* Ground Plane */}
        <mesh receiveShadow position={[0, -0.1, 0]} rotation={[-Math.PI / 2, 0, 0]}>
          <planeGeometry args={[50, 50]} />
          <meshLambertMaterial color="#90EE90" />
        </mesh>

        <Suspense fallback={null}>
          {/* Bridge Model */}
          <BridgeModel
            selectedComponent={selectedComponent}
            onSelectComponent={setSelectedComponent}
          />

          {/* Dimension Annotations */}
          {showDimensions && (
            <DimensionAnnotation />
          )}
        </Suspense>
      </Canvas>
    </div>
  );
}

export default App;
