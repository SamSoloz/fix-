import { Html } from '@react-three/drei';
import * as THREE from 'three';

export default function DimensionAnnotation() {
  // Bridge dimensions
  const slabLength = 15;
  const slabWidth = 10;
  const slabThickness = 0.8;
  const abutmentHeight = 2;
  const abutmentWidth = 1;

  return (
    <group>
      {/* Length Dimension - Top of slab */}
      <Html
        position={[0, slabThickness + 1, slabWidth / 2 + 1]}
        center
        transform
        occlude
        style={{
          background: 'white',
          padding: '4px 8px',
          borderRadius: '4px',
          fontSize: '14px',
          fontWeight: 'bold',
          border: '1px solid #333',
          pointerEvents: 'none'
        }}
      >
        {slabLength.toFixed(1)}m
      </Html>

      {/* Width Dimension - Side of slab */}
      <Html
        position={[slabLength / 2 + 1, slabThickness + 1, 0]}
        center
        transform
        occlude
        style={{
          background: 'white',
          padding: '4px 8px',
          borderRadius: '4px',
          fontSize: '14px',
          fontWeight: 'bold',
          border: '1px solid #333',
          pointerEvents: 'none'
        }}
      >
        {slabWidth.toFixed(1)}m
      </Html>

      {/* Thickness Dimension - Side view */}
      <Html
        position={[slabLength / 2 + 2, slabThickness / 2, slabWidth / 2 + 1]}
        center
        transform
        occlude
        style={{
          background: 'white',
          padding: '4px 8px',
          borderRadius: '4px',
          fontSize: '14px',
          fontWeight: 'bold',
          border: '1px solid #333',
          pointerEvents: 'none'
        }}
      >
        {slabThickness.toFixed(1)}m
      </Html>

      {/* Abutment Height Dimension */}
      <Html
        position={[-(slabLength / 2 + abutmentWidth + 1), abutmentHeight / 2, slabWidth / 2 + 1]}
        center
        transform
        occlude
        style={{
          background: 'white',
          padding: '4px 8px',
          borderRadius: '4px',
          fontSize: '14px',
          fontWeight: 'bold',
          border: '1px solid #333',
          pointerEvents: 'none'
        }}
      >
        {abutmentHeight.toFixed(1)}m
      </Html>

      {/* Abutment Width Dimension */}
      <Html
        position={[-(slabLength / 2 + abutmentWidth / 2), abutmentHeight + 1, slabWidth / 2 + 1]}
        center
        transform
        occlude
        style={{
          background: 'white',
          padding: '4px 8px',
          borderRadius: '4px',
          fontSize: '14px',
          fontWeight: 'bold',
          border: '1px solid #333',
          pointerEvents: 'none'
        }}
      >
        {abutmentWidth.toFixed(1)}m
      </Html>

      {/* Dimension Lines (using Line geometry) */}
      {/* Length dimension line */}
      <line>
        <bufferGeometry>
          <bufferAttribute
            attach="attributes-position"
            count={2}
            array={new Float32Array([
              -slabLength / 2, slabThickness + 0.8, slabWidth / 2 + 0.8,
              slabLength / 2, slabThickness + 0.8, slabWidth / 2 + 0.8
            ])}
            itemSize={3}
          />
        </bufferGeometry>
        <lineBasicMaterial color="#333333" linewidth={2} />
      </line>

      {/* Width dimension line */}
      <line>
        <bufferGeometry>
          <bufferAttribute
            attach="attributes-position"
            count={2}
            array={new Float32Array([
              slabLength / 2 + 0.8, slabThickness + 0.8, -slabWidth / 2,
              slabLength / 2 + 0.8, slabThickness + 0.8, slabWidth / 2
            ])}
            itemSize={3}
          />
        </bufferGeometry>
        <lineBasicMaterial color="#333333" linewidth={2} />
      </line>
    </group>
  );
}
