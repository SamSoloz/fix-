import { useRef, useState } from 'react';
import { Mesh, Group } from 'three';
import { ThreeEvent } from '@react-three/fiber';
import { useBridgeParameters } from '../hooks/useBridgeParameters';
import * as THREE from 'three';

interface BridgeModelProps {
  selectedComponent: string | null;
  onSelectComponent: (component: string | null) => void;
}

export default function BridgeModel({ selectedComponent, onSelectComponent }: BridgeModelProps) {
  const groupRef = useRef<Group>(null);
  const { parameters } = useBridgeParameters();
  
  // Bridge parameters
  const slabLength = 15; // 15m span
  const slabWidth = 10;  // 10m width
  const slabThickness = 0.8; // 0.8m thickness
  
  const abutmentHeight = 2; // 2m high
  const abutmentWidth = 1;  // 1m wide
  const abutmentLength = 10; // 10m width (same as slab)

  const handleComponentClick = (event: ThreeEvent<MouseEvent>, componentName: string) => {
    event.stopPropagation();
    onSelectComponent(componentName === selectedComponent ? null : componentName);
  };

  const getComponentColor = (componentName: string) => {
    if (selectedComponent === componentName) {
      return "#ff6b6b"; // Highlight selected component
    }
    return "#8e9aaf"; // Default concrete color
  };

  return (
    <group ref={groupRef}>
      {/* Bridge Slab */}
      <mesh
        position={[0, slabThickness / 2, 0]}
        castShadow
        receiveShadow
        onClick={(e) => handleComponentClick(e, 'Bridge_Slab')}
        onPointerOver={(e) => {
          e.stopPropagation();
          document.body.style.cursor = 'pointer';
        }}
        onPointerOut={() => {
          document.body.style.cursor = 'default';
        }}
      >
        <boxGeometry args={[slabLength, slabThickness, slabWidth]} />
        <meshLambertMaterial 
          color={getComponentColor('Bridge_Slab')}
          transparent
          opacity={selectedComponent && selectedComponent !== 'Bridge_Slab' ? 0.3 : 1.0}
        />
      </mesh>

      {/* Abutment 1 (Left) */}
      <mesh
        position={[-(slabLength / 2 + abutmentWidth / 2), abutmentHeight / 2, 0]}
        castShadow
        receiveShadow
        onClick={(e) => handleComponentClick(e, 'Abutment_1')}
        onPointerOver={(e) => {
          e.stopPropagation();
          document.body.style.cursor = 'pointer';
        }}
        onPointerOut={() => {
          document.body.style.cursor = 'default';
        }}
      >
        <boxGeometry args={[abutmentWidth, abutmentHeight, abutmentLength]} />
        <meshLambertMaterial 
          color={getComponentColor('Abutment_1')}
          transparent
          opacity={selectedComponent && selectedComponent !== 'Abutment_1' ? 0.3 : 1.0}
        />
      </mesh>

      {/* Abutment 2 (Right) */}
      <mesh
        position={[slabLength / 2 + abutmentWidth / 2, abutmentHeight / 2, 0]}
        castShadow
        receiveShadow
        onClick={(e) => handleComponentClick(e, 'Abutment_2')}
        onPointerOver={(e) => {
          e.stopPropagation();
          document.body.style.cursor = 'pointer';
        }}
        onPointerOut={() => {
          document.body.style.cursor = 'default';
        }}
      >
        <boxGeometry args={[abutmentWidth, abutmentHeight, abutmentLength]} />
        <meshLambertMaterial 
          color={getComponentColor('Abutment_2')}
          transparent
          opacity={selectedComponent && selectedComponent !== 'Abutment_2' ? 0.3 : 1.0}
        />
      </mesh>

      {/* Support Foundations (visual only) */}
      <mesh
        position={[-(slabLength / 2 + abutmentWidth / 2), -0.2, 0]}
        receiveShadow
      >
        <boxGeometry args={[abutmentWidth + 0.4, 0.4, abutmentLength + 0.4]} />
        <meshLambertMaterial color="#666666" />
      </mesh>

      <mesh
        position={[slabLength / 2 + abutmentWidth / 2, -0.2, 0]}
        receiveShadow
      >
        <boxGeometry args={[abutmentWidth + 0.4, 0.4, abutmentLength + 0.4]} />
        <meshLambertMaterial color="#666666" />
      </mesh>
    </group>
  );
}
