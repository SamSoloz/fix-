interface ComponentTreeProps {
  selectedComponent: string | null;
  onSelectComponent: (component: string | null) => void;
}

export default function ComponentTree({ selectedComponent, onSelectComponent }: ComponentTreeProps) {
  const components = [
    {
      id: 'Bridge_Slab',
      name: 'Bridge Slab',
      type: 'Concrete Slab',
      visible: true
    },
    {
      id: 'Abutment_1',
      name: 'Abutment 1',
      type: 'Concrete Abutment',
      visible: true
    },
    {
      id: 'Abutment_2',
      name: 'Abutment 2',
      type: 'Concrete Abutment',
      visible: true
    }
  ];

  return (
    <div className="bg-white rounded-lg shadow-lg p-4 w-64">
      <h3 className="text-lg font-semibold text-gray-800 mb-4">Components</h3>
      
      <div className="space-y-2">
        {components.map((component) => (
          <div
            key={component.id}
            className={`p-3 rounded-md border cursor-pointer transition-all ${
              selectedComponent === component.id
                ? 'border-blue-500 bg-blue-50'
                : 'border-gray-200 hover:border-gray-300 hover:bg-gray-50'
            }`}
            onClick={() => onSelectComponent(component.id)}
          >
            <div className="flex items-center justify-between">
              <div>
                <div className="font-medium text-gray-800">{component.name}</div>
                <div className="text-sm text-gray-600">{component.type}</div>
              </div>
              <div className="flex items-center gap-2">
                <div className={`w-3 h-3 rounded-full ${component.visible ? 'bg-green-500' : 'bg-gray-400'}`} />
              </div>
            </div>
          </div>
        ))}
      </div>

      <div className="mt-4 pt-4 border-t border-gray-200">
        <h4 className="font-medium text-gray-700 mb-2">Project Info</h4>
        <div className="text-sm text-gray-600 space-y-1">
          <div>Bridge Type: Single Span</div>
          <div>Total Length: 15.0 m</div>
          <div>Width: 10.0 m</div>
          <div>Components: 3</div>
        </div>
      </div>
    </div>
  );
}
