import { ViewMode } from '../App';

interface ViewControlsProps {
  viewMode: ViewMode;
  onViewModeChange: (mode: ViewMode) => void;
  showDimensions: boolean;
  onToggleDimensions: () => void;
  showMaterials: boolean;
  onToggleMaterials: () => void;
}

export default function ViewControls({
  viewMode,
  onViewModeChange,
  showDimensions,
  onToggleDimensions,
  showMaterials,
  onToggleMaterials
}: ViewControlsProps) {
  const viewModes: { key: ViewMode; label: string }[] = [
    { key: 'perspective', label: '3D View' },
    { key: 'plan', label: 'Plan View' },
    { key: 'front', label: 'Front Elevation' },
    { key: 'side', label: 'Side Elevation' }
  ];

  return (
    <div className="bg-white rounded-lg shadow-lg p-4 flex gap-4 items-center">
      {/* View Mode Buttons */}
      <div className="flex gap-2">
        <span className="text-sm font-medium text-gray-700 mr-2">View:</span>
        {viewModes.map(({ key, label }) => (
          <button
            key={key}
            onClick={() => onViewModeChange(key)}
            className={`px-3 py-1 rounded text-sm font-medium transition-colors ${
              viewMode === key
                ? 'bg-blue-600 text-white'
                : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
            }`}
          >
            {label}
          </button>
        ))}
      </div>

      {/* Separator */}
      <div className="w-px h-6 bg-gray-300" />

      {/* Toggle Options */}
      <div className="flex gap-4">
        <label className="flex items-center gap-2 text-sm font-medium text-gray-700">
          <input
            type="checkbox"
            checked={showDimensions}
            onChange={onToggleDimensions}
            className="rounded"
          />
          Dimensions
        </label>
        
        <label className="flex items-center gap-2 text-sm font-medium text-gray-700">
          <input
            type="checkbox"
            checked={showMaterials}
            onChange={onToggleMaterials}
            className="rounded"
          />
          Materials
        </label>
      </div>
    </div>
  );
}
