export default function MaterialProperties() {
  const materials = [
    {
      name: 'Concrete C30/37',
      density: '2400 kg/m³',
      compressiveStrength: '30 MPa',
      elasticModulus: '33 GPa',
      color: '#8e9aaf'
    }
  ];

  const bridgeVolumes = {
    slab: 15 * 10 * 0.8, // 120 m³
    abutment1: 1 * 2 * 10, // 20 m³
    abutment2: 1 * 2 * 10, // 20 m³
  };

  const totalVolume = bridgeVolumes.slab + bridgeVolumes.abutment1 + bridgeVolumes.abutment2;
  const totalMass = totalVolume * 2400; // kg

  return (
    <div className="bg-white rounded-lg shadow-lg p-4 w-80">
      <h3 className="text-lg font-semibold text-gray-800 mb-4">Material Properties</h3>
      
      {materials.map((material, index) => (
        <div key={index} className="mb-6 p-3 border border-gray-200 rounded-md">
          <div className="flex items-center gap-3 mb-3">
            <div 
              className="w-4 h-4 rounded"
              style={{ backgroundColor: material.color }}
            />
            <h4 className="font-medium text-gray-800">{material.name}</h4>
          </div>
          
          <div className="space-y-2 text-sm text-gray-600">
            <div className="flex justify-between">
              <span>Density:</span>
              <span className="font-medium">{material.density}</span>
            </div>
            <div className="flex justify-between">
              <span>Compressive Strength:</span>
              <span className="font-medium">{material.compressiveStrength}</span>
            </div>
            <div className="flex justify-between">
              <span>Elastic Modulus:</span>
              <span className="font-medium">{material.elasticModulus}</span>
            </div>
          </div>
        </div>
      ))}

      <div className="border-t border-gray-200 pt-4">
        <h4 className="font-medium text-gray-700 mb-3">Volume Calculation</h4>
        <div className="space-y-2 text-sm text-gray-600">
          <div className="flex justify-between">
            <span>Bridge Slab:</span>
            <span className="font-medium">{bridgeVolumes.slab.toFixed(1)} m³</span>
          </div>
          <div className="flex justify-between">
            <span>Abutment 1:</span>
            <span className="font-medium">{bridgeVolumes.abutment1.toFixed(1)} m³</span>
          </div>
          <div className="flex justify-between">
            <span>Abutment 2:</span>
            <span className="font-medium">{bridgeVolumes.abutment2.toFixed(1)} m³</span>
          </div>
          <div className="flex justify-between border-t pt-2 font-medium">
            <span>Total Volume:</span>
            <span>{totalVolume.toFixed(1)} m³</span>
          </div>
          <div className="flex justify-between font-medium">
            <span>Total Mass:</span>
            <span>{(totalMass / 1000).toFixed(0)} tonnes</span>
          </div>
        </div>
      </div>

      <div className="mt-4 p-3 bg-blue-50 rounded-md">
        <h5 className="font-medium text-blue-800 mb-1">Reinforcement Notes</h5>
        <p className="text-sm text-blue-700">
          Main reinforcement: 16mm @ 200mm c/c both ways
        </p>
        <p className="text-sm text-blue-700">
          Distribution steel: 12mm @ 300mm c/c
        </p>
      </div>
    </div>
  );
}
