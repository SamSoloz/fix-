import * as THREE from 'three';

export interface BridgeGeometryParams {
  slabLength: number;
  slabWidth: number;
  slabThickness: number;
  abutmentHeight: number;
  abutmentWidth: number;
  abutmentLength: number;
}

export class BridgeGeometry {
  static createSlabGeometry(length: number, width: number, thickness: number): THREE.BoxGeometry {
    return new THREE.BoxGeometry(length, thickness, width);
  }

  static createAbutmentGeometry(width: number, height: number, length: number): THREE.BoxGeometry {
    return new THREE.BoxGeometry(width, height, length);
  }

  static calculateSlabPosition(thickness: number): [number, number, number] {
    return [0, thickness / 2, 0];
  }

  static calculateAbutment1Position(
    slabLength: number, 
    abutmentWidth: number, 
    abutmentHeight: number
  ): [number, number, number] {
    return [-(slabLength / 2 + abutmentWidth / 2), abutmentHeight / 2, 0];
  }

  static calculateAbutment2Position(
    slabLength: number, 
    abutmentWidth: number, 
    abutmentHeight: number
  ): [number, number, number] {
    return [slabLength / 2 + abutmentWidth / 2, abutmentHeight / 2, 0];
  }

  static calculateTotalVolume(params: BridgeGeometryParams): number {
    const slabVolume = params.slabLength * params.slabWidth * params.slabThickness;
    const abutmentVolume = params.abutmentWidth * params.abutmentHeight * params.abutmentLength;
    return slabVolume + (2 * abutmentVolume);
  }

  static generateDimensionAnnotations(params: BridgeGeometryParams) {
    return {
      slab: {
        length: { value: params.slabLength, position: [0, params.slabThickness + 1, params.slabWidth / 2 + 1] },
        width: { value: params.slabWidth, position: [params.slabLength / 2 + 1, params.slabThickness + 1, 0] },
        thickness: { value: params.slabThickness, position: [params.slabLength / 2 + 2, params.slabThickness / 2, params.slabWidth / 2 + 1] }
      },
      abutments: {
        height: { value: params.abutmentHeight, position: [-(params.slabLength / 2 + params.abutmentWidth + 1), params.abutmentHeight / 2, params.slabWidth / 2 + 1] },
        width: { value: params.abutmentWidth, position: [-(params.slabLength / 2 + params.abutmentWidth / 2), params.abutmentHeight + 1, params.slabWidth / 2 + 1] }
      }
    };
  }
}

export default BridgeGeometry;
