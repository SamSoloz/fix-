import { useState } from 'react';

interface BridgeParameters {
  slabLength: number;
  slabWidth: number;
  slabThickness: number;
  abutmentHeight: number;
  abutmentWidth: number;
  abutmentLength: number;
  materialGrade: string;
  reinforcement: {
    main: string;
    distribution: string;
  };
}

export function useBridgeParameters() {
  const [parameters, setParameters] = useState<BridgeParameters>({
    slabLength: 15.0,      // 15m span
    slabWidth: 10.0,       // 10m width
    slabThickness: 0.8,    // 0.8m thickness
    abutmentHeight: 2.0,   // 2m high
    abutmentWidth: 1.0,    // 1m wide
    abutmentLength: 10.0,  // 10m width
    materialGrade: 'C30/37',
    reinforcement: {
      main: '16mm @ 200mm c/c both ways',
      distribution: '12mm @ 300mm c/c'
    }
  });

  const updateParameter = <K extends keyof BridgeParameters>(
    key: K,
    value: BridgeParameters[K]
  ) => {
    setParameters(prev => ({
      ...prev,
      [key]: value
    }));
  };

  const calculateVolumes = () => {
    const slabVolume = parameters.slabLength * parameters.slabWidth * parameters.slabThickness;
    const abutment1Volume = parameters.abutmentWidth * parameters.abutmentHeight * parameters.abutmentLength;
    const abutment2Volume = parameters.abutmentWidth * parameters.abutmentHeight * parameters.abutmentLength;
    const totalVolume = slabVolume + abutment1Volume + abutment2Volume;

    return {
      slab: slabVolume,
      abutment1: abutment1Volume,
      abutment2: abutment2Volume,
      total: totalVolume
    };
  };

  const calculateMass = (density: number = 2400) => {
    const volumes = calculateVolumes();
    return volumes.total * density; // kg
  };

  return {
    parameters,
    updateParameter,
    calculateVolumes,
    calculateMass
  };
}
